jQuery.noConflict();

jQuery(document).ready(function() {

	// enable config manager
	initConfigManager();
	// help icons
	generateHelpIcons();
	generateFormElements();
	// load the template updates
	getUpdates();
	// get translations
	var $lang = getTranslations();

	// fonts forms
	jQuery('.gkfont_form').each(function(i, el) {
		el = jQuery(el);

		var base_id = el.find('input');
		base_id = jQuery(base_id).attr('id');

		var base_el = jQuery('#' + base_id);
		if(base_el.val() === '') base_el.attr('value','standard;Arial, Helvetica, sans-serif');
		var values = (base_el.val()).split(';');

		// id of selectbox are different from input id
		base_id = base_id.replace('jform_params_font_', 'jformparamsfont_');
		jQuery('#'+base_id + '_type').val(values[0]);
		if(values[0] == 'standard') {
			jQuery('#' + base_id + '_normal').val(values[1]);
			jQuery('#' + base_id + '_normal').fadeIn();
			jQuery('#' + base_id + '_normal').css("cssText","display: block !important;");
			jQuery('#' + base_id + '_google_own_link').fadeOut();
			jQuery('#' + base_id + '_google_own_font').fadeOut();
			jQuery('#' + base_id + '_google_own_link_label').fadeOut();
			jQuery('#' + base_id + '_google_own_font_label').fadeOut();
			jQuery('#' + base_id + '_squirrel').fadeOut();
			jQuery('#' + base_id + '_adobe_edge_url_label').fadeOut();
		} else if(values[0] == 'google') {
			jQuery('#' + base_id + '_google_own_link').val(values[2]);
			jQuery('#' + base_id + '_google_own_font').val(values[3]);
			jQuery('#' + base_id + '_normal').fadeOut();
			jQuery('#' + base_id + '_normal').css("cssText","display: none !important;");
			jQuery('#' + base_id + '_squirrel').css("cssText","display: none !important;");
			jQuery('#' + base_id + '_squirrel').fadeOut();
			jQuery('#' + base_id + '_adobe_edge_url_label').fadeOut();
		} else if(values[0] == 'squirrel') {
			jQuery('#' + base_id + '_squirrel').val(values[1]);
			jQuery('#' + base_id + '_squirrel').css("cssText","display: block !important;");
			jQuery('#' + base_id + '_normal').fadeOut();
			jQuery('#' + base_id + '_normal').css("cssText","display: none !important;");
			jQuery('#' + base_id + '_google_own_link').fadeOut();
			jQuery('#' + base_id + '_google_own_font').fadeOut();
			jQuery('#' + base_id + '_google_own_link_label').fadeOut();
			jQuery('#' + base_id + '_google_own_font_label').fadeOut();
			jQuery('#' + base_id + '_adobe_edge_url_label').fadeOut();
		} else if(values[0] == 'adobe') {
			jQuery('#' + base_id + '_adobe_edge_url').val(values[1]);
			jQuery('#' + base_id + '_adobe_edge_url_label').fadeIn();
			jQuery('#' + base_id + '_normal').fadeOut();
			jQuery('#' + base_id + '_normal').css("cssText","display: none !important;");
			jQuery('#' + base_id + '_google_own_link').fadeOut();
			jQuery('#' + base_id + '_google_own_font').fadeOut();
			jQuery('#' + base_id + '_google_own_link_label').fadeOut();
			jQuery('#' + base_id + '_google_own_font_label').fadeOut();
			jQuery('#' + base_id + '_squirrel').fadeOut();
			jQuery('#' + base_id + '_squirrel').css("cssText","display: none !important;");
		}

		jQuery('#' + base_id + '_type').change(function() {
				var values = (base_el.val()).split(';');

				if(jQuery('#' + base_id + '_type').val() == 'standard') {
					jQuery('#' + base_id + '_normal').fadeIn();

					jQuery('#' + base_id + '_normal').trigger('change');
					jQuery('#' + base_id + '_normal').css("cssText","display: block !important;");
					jQuery('#' + base_id + '_google_own_link').fadeOut();
					jQuery('#' + base_id + '_google_own_font').fadeOut();
					jQuery('#' + base_id + '_google_own_link_label').fadeOut();
					jQuery('#' + base_id + '_google_own_font_label').fadeOut();
					jQuery('#' + base_id + '_squirrel').fadeOut();
					jQuery('#' + base_id + '_squirrel').css("cssText","display: none !important;");
					jQuery('#' + base_id + '_adobe_edge_url_label').fadeOut();
				} else if(jQuery('#' + base_id + '_type').val() == 'google') {
					jQuery('#' + base_id + '_normal').fadeOut();
					jQuery('#' + base_id + '_normal').css("cssText","display: none !important;");
					jQuery('#' + base_id + '_google_own_link').fadeIn();
					jQuery('#' + base_id + '_google_own_font').fadeIn();
					jQuery('#' + base_id + '_google_own_font').trigger('change');
					jQuery('#' + base_id + '_google_own_link_label').fadeIn();
					jQuery('#' + base_id + '_google_own_font_label').fadeIn();
					jQuery('#' + base_id + '_squirrel').fadeOut();
					jQuery('#' + base_id + '_squirrel').css("cssText","display: none !important;");
					jQuery('#' + base_id + '_adobe_edge_url_label').fadeOut();
				} else if(jQuery('#' + base_id + '_type').val() == 'squirrel') {
					jQuery('#' + base_id + '_normal').fadeOut();
					jQuery('#' + base_id + '_normal').css("cssText","display: none !important;");
					jQuery('#' + base_id + '_google_own_link').fadeOut();
					jQuery('#' + base_id + '_google_own_font').fadeOut();
					jQuery('#' + base_id + '_google_own_link_label').fadeOut();
					jQuery('#' + base_id + '_google_own_font_label').fadeOut();
					jQuery('#' + base_id + '_adobe_edge_url_label').fadeOut();
					jQuery('#' + base_id + '_squirrel').fadeIn();
					jQuery('#' + base_id + '_squirrel').trigger('change');
					jQuery('#' + base_id + '_squirrel').css("cssText","display: block !important;");
				} else if(jQuery('#' + base_id + '_type').val() == 'adobe') {
		           jQuery('#' + base_id + '_normal').fadeOut();
		           jQuery('#' + base_id + '_normal').css("cssText","display: none !important;");
		           jQuery('#' + base_id + '_google_own_link').fadeOut();
		           jQuery('#' + base_id + '_google_own_font').fadeOut();
		           jQuery('#' + base_id + '_google_own_link_label').fadeOut();
		           jQuery('#' + base_id + '_google_own_font_label').fadeOut();
		           jQuery('#' + base_id + '_squirrel').fadeOut();
		           jQuery('#' + base_id + '_squirrel').css("cssText","display: none !important;");
		           jQuery('#' + base_id + '_adobe_edge_url_label').fadeIn();
		           jQuery('#' + base_id + '_adobe_edge_url').trigger('change');
		       }

			});
			jQuery('#' + base_id + '_type').blur(function() {
				var values = (base_el.val()).split(';');

				if(jQuery('#' + base_id + '_type').val() == 'standard') {
					jQuery('#' + base_id + '_normal').fadeIn();
					jQuery('#' + base_id + '_normal').trigger('change');
					jQuery('#' + base_id + '_google_own_link').fadeOut();
					jQuery('#' + base_id + '_google_own_font').fadeOut();
					jQuery('#' + base_id + '_google_own_link_label').fadeOut();
					jQuery('#' + base_id + '_google_own_font_label').fadeOut();
					jQuery('#' + base_id + '_squirrel').css('display', 'none');
					jQuery('#' + base_id + '_adobe_edge_url_label').fadeOut();
				} else if(jQuery('#' + base_id + '_type').val() == 'google') {
					jQuery('#' + base_id + '_normal').fadeOut();
					jQuery('#' + base_id + '_google_own_link').fadeIn();
					jQuery('#' + base_id + '_google_own_font').fadeIn();
					jQuery('#' + base_id + '_google_own_font').trigger('change');
					jQuery('#' + base_id + '_google_own_link_label').fadeIn();
					jQuery('#' + base_id + '_google_own_font_label').fadeIn();
					jQuery('#' + base_id + '_squirrel').css('display', 'none');
					jQuery('#' + base_id + '_adobe_edge_url_label').fadeOut();
				} else if(jQuery('#' + base_id + '_type').val() == 'squirrel') {
					jQuery('#' + base_id + '_normal').fadeOut();
					jQuery('#' + base_id + '_google_own_link').fadeOut();
					jQuery('#' + base_id + '_google_own_font').fadeOut();
					jQuery('#' + base_id + '_google_own_link_label').fadeOut();
					jQuery('#' + base_id + '_google_own_font_label').fadeOut();
					jQuery('#' + base_id + '_adobe_edge_url_label').fadeOut();
					jQuery('#' + base_id + '_squirrel').fadeIn();
					jQuery('#' + base_id + '_squirrel').trigger('change');

				} else if(jQuery('#' + base_id + '_type').val() == 'adobe') {
				    jQuery('#' + base_id + '_normal').fadeOut();
				    jQuery('#' + base_id + '_google_own_link').fadeOut();
				    jQuery('#' + base_id + '_google_own_font').fadeOut();
				    jQuery('#' + base_id + '_google_own_link_label').fadeOut();
				    jQuery('#' + base_id + '_google_own_font_label').fadeOut();
				    jQuery('#' + base_id + '_squirrel').fadeOut();
					jQuery('#' + base_id + '_adobe_edge_url_label').fadeIn();
				}
		});


		jQuery('#' + base_id + '_normal').change(function() {
			base_el.val(jQuery('#' + base_id + '_type').val() + ';' + jQuery('#' + base_id + '_normal').val());
		});
		jQuery('#' + base_id + '_normal').blur(function()  {
			base_el.val(jQuery('#' + base_id + '_type').val() + ';' + jQuery('#' + base_id + '_normal').val());
		});


		jQuery('#' + base_id + '_google_own_link').keydown(function() {
			base_el.attr(
				'value',
				jQuery('#' + base_id + '_type').val() + ';' +
				'own;' +
				jQuery('#' + base_id + '_google_own_link').val() + ';' +
				jQuery('#' + base_id + '_google_own_font').val()
			);
		});
		jQuery('#' + base_id + '_google_own_link').blur(function() {
			base_el.attr(
				'value',
				jQuery('#' + base_id + '_type').val() + ';' +
				'own;' +
				jQuery('#' + base_id + '_google_own_link').val() + ';' +
				jQuery('#' + base_id + '_google_own_font').val()
			);
		});

		jQuery('#' + base_id + '_google_own_font').keydown(function() {
			base_el.attr(
				'value',
				jQuery('#' + base_id + '_type').val() + ';' +
				'own;' +
				jQuery('#' + base_id + '_google_own_link').val() + ';' +
				jQuery('#' + base_id + '_google_own_font').val()
			);
		});
		jQuery('#' + base_id + '_google_own_font').blur(function() {
			base_el.attr(
				'value',
				jQuery('#' + base_id + '_type').val() + ';' +
				'own;' +
				jQuery('#' + base_id + '_google_own_link').val() + ';' +
				jQuery('#' + base_id + '_google_own_font').val()
			);
		});


		jQuery('#' + base_id + '_squirrel').change(function() {
			base_el.val(jQuery('#' + base_id + '_type').val() + ';' + jQuery('#' + base_id + '_squirrel').val());
		});
		jQuery('#' + base_id + '_squirrel').blur(function() { base_el.val(jQuery('#' + base_id + '_type').val() + ';' + jQuery('#' + base_id + '_squirrel').val());
		});


		jQuery('#' + base_id + '_adobe_edge_url').change(function() {
			base_el.val(jQuery('#' + base_id + '_type').val() + ';' + jQuery('#' + base_id + '_adobe_edge_url').val());
		});
		jQuery('#' + base_id + '_adobe_edge_url').blur(function()  {
			base_el.val(jQuery('#' + base_id + '_type').val() + ';' + jQuery('#' + base_id + '_adobe_edge_url').val());
		});

	});

	jQuery('.gkFormLine').each(function(i, el) {
		el = jQuery(el);
		el.parent().css('margin', '0');
		el.parents().eq(1).find('.control-label').css('display', 'none');
		el.parents().eq(1).css('border', 'none');
		//el.parents().eq(2).find('.control-label').css('display', 'none');

	});

	// overrides
	var elements = ['layout_override', 'tools_for_pages', 'suffix_override', 'module_override', 'mootools_for_pages', 'sidebar_width_for_pages', 'inset_width_for_pages'];
	jQuery.each(elements, function(i, txt) {
		var rules = jQuery("#"+txt + '_rules');
		var textarea = jQuery("#jform_params_"+txt+"");

		var items = textarea.val().split( /\r\n|\r|\n/ );

		for(var i = 0; i < items.length; i++) {
			if(items[i] != "") {
				var item = jQuery('<div>');
				var type = !isNaN(items[i].split('=')[0]) ? 'ItemID' : 'Option';
				item.html('<em>' + type + '</em> <strong>' + items[i].split('=')[0] + '</strong> - <strong>' + items[i].split('=')[1] + '</strong> <a href="#" class="' + txt + '_remove_rule">' + $lang['tpl_js_remove_rule'] + '</a>');
				rules.append(item);
			}
		}

		rules.on('click',function(e){
			e.stopPropagation();
			e.preventDefault();

			if(e.target.hasClass(txt + '_remove_rule')) {
				var parent = e.target.parent();
				var values = parent.find('strong');
				textarea.html(textarea.html().replace(values[0].html() + "=" + values[1].html() + "\n", ''));
				parent.remove();
			}
		});

		jQuery("#" + txt + '_add_btn').on('click',function(){
			var rule = jQuery("#" + txt + '_input').attr('value') + "=" + ((jQuery("#" + txt + '_select')) ? jQuery("#" + txt + '_select').attr('value') : 'enabled') + "\n";

			if(textarea.html().indexOf(rule) > -1) {
				alert($lang['tpl_js_specified_rule_exists']);
			} else {
				textarea.append(rule);
				var item = jQuery('<div>');
				var type = !isNaN(jQuery("#" + txt + '_input').attr('value')) ? 'ItemID' : 'Option';
				var value = jQuery("#" + txt + '_input').attr('value');
				var layout = jQuery("#" + txt + '_select') ? jQuery("#" + txt + '_select').attr('value') : '';
				item.html('<em>' + type + '</em> <strong>' + value + '</strong> <strong>' + layout + '</strong> <a href="#" class="' + txt + '_remove_rule">' + $lang['tpl_js_remove_rule'] + '</a>');
				rules.append(item);
			}
		});
	});

	// layout override
	var grules = jQuery('#google_analytics_rules');
	var gtextarea = jQuery('#jform_params_google_analytics');
	var gitems = gtextarea.val().split( /\r\n|\r|\n/ );

	for(var i = 0; i < gitems.length; i++) {
		if(gitems[i] != "") {
			var gitem = new jQuery('<div>');
			gitem.html('<strong>' + gitems[i] + '</strong> <a href="#" class="google_analytics_remove_rule">' + $lang['tpl_js_remove_rule'] + '</a>');
			gitem.append(grules);
		}
	}
	grules.on('click', function(e){
		e.stopPropagation();
		e.preventDefault();
		if(e.target.hasClass('google_analytics_remove_rule')) {
			var parent = e.target.parent();
			var values = parent.find('strong');
			gtextarea.html(gtextarea.html().replace(values.html() + "\n", ''));
			parent.remove();
		}
	});
	jQuery('#google_analytics_add_btn').on('click',function(){
		var rule = jQuery('#google_analytics_input').attr('value') + "\n";

		if(gtextarea.html().indexOf(rule) > -1) {
			alert($lang['tpl_js_specified_rule_exists']);
		} else {
			gtextarea.append(rule);
			var item = jQuery('<div>');
			var value = jQuery('#google_analytics_input').attr('value');
			item.html('<strong>' + value + '</strong> <a href="#" class="google_analytics_remove_rule">' + $lang['tpl_js_remove_rule'] + '</a>');
			item.append(grules);
		}
	});
	// other form operations
	jQuery('.input-pixels').each(function(i, el){
		el = jQuery(el);
		el.parent().html("<div class=\"input-prepend\">" + el.parent().html() + "<span class=\"add-on\">px</span></div>");
	});

	jQuery('.input-percents').each(function(i, el){
		el = jQuery(el);
		el.parent().html("<div class=\"input-prepend\">" + el.parent().html() + "<span class=\"add-on\">%</span></div>");
	});
	jQuery('.input-ms').each(function(i, el){
		el = jQuery(el);
		el.parent().html("<div class=\"input-prepend\">" + el.parent().html() + "<span class=\"add-on\">ms</span></div>");
	});
	jQuery('#gk_template_updates').parent().css('margin-left', '10px');
	jQuery('#config_manager_form').parent().css('margin-left', '10px');
	jQuery('#jform_params_asset_js-lbl').parents().eq(1).css('display', 'none');
	jQuery('#jform_params_asset_css-lbl').parents().eq(1).css('display', 'none');
	jQuery('#jform_params_js_translations-lbl').parents().eq(1).css('display', 'none');

	// function to generate the help icons
	function generateHelpIcons() {

		var urls = [
			'https://www.gavick.com/documentation/joomla-templates/gavern-framework/gavern-framework-page-layout-part-1/',
			'https://www.gavick.com/documentation/joomla-templates/gavern-framework/gavern-framework-page-layout-part-2/',
			'https://www.gavick.com/documentation/joomla-templates/gavern-framework/gavern-framework-fonts/',
			'https://www.gavick.com/documentation/joomla-templates/gavern-framework/gavern-3-0-features/',
			'https://www.gavick.com/documentation/joomla-templates/gavern-framework/gavern-3-0-menu/',
			'https://www.gavick.com/documentation/joomla-templates/gavern-framework/gavern-framework-social-api/',
			'https://www.gavick.com/documentation/joomla-templates/gavern-framework/cookie-law/',
			'https://www.gavick.com/documentation/joomla-templates/gavern-framework/gavern-3-0-advanced-settings/',
			'https://www.gavick.com/updates.html'
		];

		jQuery('div.accordion-group').each(function(i, el) {
			if(i > urls.length) { return true; }
			var link = jQuery('<a>', {
				class : 'gkHelpLink',
				href : urls[i],
				target : '_blank'
			});
			el = jQuery(el);
			el.find('div.accordion-heading strong').append(link);
			link.on('click',function(e) { e.stopPropagation();});

		});
	}

	if(jQuery('#jform_params_tools').val() != 'selected' && jQuery('#jform_params_tools').val() != 'selected_disabled') jQuery('#jform_params_tools_for_pages-lbl').parent().css('display','none');

	  jQuery('#jform_params_tools').change(function(){
		if(jQuery('#jform_params_tools').val() == 'selected' || jQuery('#jform_params_tools').val() == 'selected_disabled') jQuery('#jform_params_tools_for_pages-lbl').parents().eq(1).fadeIn();
		else jQuery('#jform_params_tools_for_pages-lbl').parents().eq(1).fadeOut();
	  });



	// function to generate the updates list
	function getUpdates() {
		jQuery('#jform_params_template_updates-lbl').hide();

		var $update = jQuery('#gk_template_updates');
		var $check = jQuery('.gk-version-check');
		var $version = jQuery('.gk-tpl-version');

		var tplVersion = $update.attr('data-gktplversion');
		$version.text(tplVersion);
		$check.show();

		var tpl = $update.attr('data-tpl');
		var gkparams = Joomla.getOptions('gkparams');
		var juri_root = gkparams.juri_root;
		var token = gkparams.token;
		var url = juri_root + '?template=' + tpl + '&tmpl=gkupdate&token=' + token;

		setTimeout(function () {
			jQuery.ajax({
				url: url,
				dataType: 'json'
			})
			.done(function(data) {
				$check.html(data.msg);
			})
			.fail(function() {
				$check.html('<div calss="gk-msg gk-error">Check update failed!</div>');
			})
		}, 300)
	}

	function getTranslations() {
		var translations = [];

		jQuery('#template_options_translations span').each(function(i,el){
			el = jQuery(el);
			translations[el.attr('id')] = el.html();
		});

		return translations;
	}

	function generateFormElements() {
		// remove next label
		var buf = null;
		jQuery('.next-remove').each(function(i, el) {
			if(i % 2 == 0) {
				el.parent().find('label').remove();
				buf = el.parent().hmtl();
				el.parent().remove();
			} else {
				el.parent().append(buf);
			}
		});
		// create suffix labels
		jQuery('.suffix-px').each(function(i, el) {
			var suff = jQuery('<span>', {'class' : 'gkFormSuffixPx', 'html' : 'px'});
			el.append(suff);
		});
		jQuery('.suffix-percents').each(function(i, el) {
			var suff = jQuery('span', {'class' : 'gkFormSuffixPercents', 'html' : '%'});
			el.append(suff);
		});
		jQuery('.suffix-pxorpercents').each(function(i, el) {
			var suff = jQuery('span', {'class' : 'gkFormSuffixPxOrPercents', 'html' : ''});
			el.append(suff);
		});
	}


	// init config manager
	function initConfigManager() {
		var loadbtn = jQuery('#config_manager_load');
		var savebtn = jQuery('#config_manager_save');
		var deletebtn = jQuery('#config_manager_delete');

		loadbtn.on('click',function(e) {
			e.stopPropagation();
			e.preventDefault();
			loadSaveOperation('load');
		});
		savebtn.on('click',function(e) {
			e.stopPropagation();
			e.preventDefault();
			loadSaveOperation('save');
		});
		deletebtn.on('click',function(e) {
			e.stopPropagation();
			e.preventDefault();
			loadSaveOperation('delete');
		});
	}
	// function to load/save settings
	function loadSaveOperation(type) {
		var current_url = window.location;
		if((current_url + '').indexOf('#', 0) === -1) {
			current_url = current_url + '&gk_template_task='+type+'&gk_template_file=' + jQuery('#config_manager_'+type+'_filename').val();
		} else {
			current_url = current_url.substr(0, (current_url + '').indexOf('#', 0) - 1);
			current_url = current_url + '&gk_template_task='+type+'&gk_template_file=' + jQuery('config_manager_'+type+'_filename').val();
		}
		window.location = current_url;
	}


	if (jQuery('#gk_template_updates').length && jQuery('#style-form').length) {
		if (parseFloat((jQuery('#gk_template_updates').data('jversion')).substr(0, 3)) >= '4') {
			$('#style-form').addClass('j32 j4');
		} else if (parseFloat((jQuery('#gk_template_updates').data('jversion')).substr(0, 3)) >= '3.2') {
			jQuery('#style-form').addClass('j32');
			jQuery('.j32 .switcher').addClass('btn-group btn-group-yesno');

			// Turn radios into btn-group
			jQuery('.radio.btn-group label').addClass('btn');

			jQuery('fieldset.btn-group').each(function () {
				// Handle disabled, prevent clicks on the container, and add disabled style to each button
				if (jQuery(this).prop('disabled')) {
					jQuery(this).css('pointer-events', 'none').off('click');
					jQuery(this).find('.btn').addClass('disabled');
				}
			});

			jQuery('.btn-group label:not(.active)').off().unbind().click(function ()
			{
				var label = jQuery(this);
				var input = jQuery('#' + label.attr('for'));

				if (!input.prop('checked'))
				{
					label.closest('.btn-group').find('label').removeClass('active btn-success btn-danger btn-primary');

					if (label.closest('.btn-group').hasClass('btn-group-reversed'))
					{
						if (input.val() == '')
						{
							label.addClass('active btn-primary');
						} else if (input.val() == 0)
						{
							label.addClass('active btn-success');
						} else
						{
							label.addClass('active btn-danger');
						}
					} else
					{
						if (input.val() == '')
						{
							label.addClass('active btn-primary');
						} else if (input.val() == 0)
						{
							label.addClass('active btn-danger');
						} else
						{
							label.addClass('active btn-success');
						}

					}
					input.prop('checked', true);
					input.trigger('change');
				}
			});
			jQuery('.btn-group input[checked=checked]').each(function ()
			{
				var $self = jQuery(this);
				var attrId = $self.attr('id');

				if ($self.parent().hasClass('btn-group-reversed'))
				{
					if ($self.val() == '')
					{
						jQuery('label[for=' + attrId + ']').addClass('active btn-primary');
					} else if ($self.val() == 0)
					{
						jQuery('label[for=' + attrId + ']').addClass('active btn-success');
					} else
					{
						jQuery('label[for=' + attrId + ']').addClass('active btn-danger');
					}
				} else
				{
					if ($self.val() == '')
					{
						jQuery('label[for=' + attrId + ']').addClass('active btn-primary');
					} else if ($self.val() == 0)
					{
						jQuery('label[for=' + attrId + ']').addClass('active btn-danger');
					} else
					{
						jQuery('label[for=' + attrId + ']').addClass('active btn-success');
					}
				}
			});
		}
	}
});
