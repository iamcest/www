<?php

defined('JPATH_BASE') or die;

if(!defined('DS')){
   define('DS',DIRECTORY_SEPARATOR);
}

jimport('joomla.form.formfield');

class JFormFieldAsset extends JFormField {
     protected $type = 'Asset';

  protected function getInput() {
    $doc = JFactory::getDocument();

    if($this->element['extension'] == 'js') {
      if (isJoomla4()) {
        $doc->addScript(JURI::root().str_replace('.js','4.js',$this->element['path']));
      } else {
        $doc->addScript(JURI::root().$this->element['path']);     
      }
         
    } else {
      if (isJoomla4()) {
        $doc->addStyleSheet(JURI::root().str_replace('.css','4.css',$this->element['path']));
      } else {
        $doc->addStyleSheet(JURI::root().$this->element['path']);       
      }
    }

    return;
  }
}

/* EOF */
