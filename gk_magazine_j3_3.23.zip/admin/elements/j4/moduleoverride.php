<?php

class JFormFieldModuleOverride extends JFormField
{
	public $type = 'ModuleOverride';

	protected function getInput() {
		$module_positions = explode(',', $this->element['module_positions']);
		$module_styles = explode(',', $this->element['module_styles']);
		$options_mp = array();
		$options_ms = array();

		foreach($module_positions as $pos) {
			$options_mp[] = JHtml::_('select.option', $pos, $pos);
		}

		foreach($module_styles as $style) {
			$options_ms[] = JHtml::_('select.option', $style, $style);
		}

		$html = '';
		$html .= '<div id="module_override_form">';
		$html .= '<div class="input-group"><span class="input-group-addon">' . JText::_('TPL_GK_LANG_ADD_RULE_MOD_POS') . '</span>';
		$html .= JHtml::_('select.genericlist', $options_mp, 'name', 'class="form-control custom-select"', 'value', 'text', 'default', 'module_override_input') . '</div>';
		$html .= '<div class="input-group"><span class="input-group-addon">' . JText::_('TPL_GK_LANG_ADD_RULE_STYLE') . '</span>';
		$html .= JHtml::_('select.genericlist', $options_ms, 'name', 'class="form-control custom-select"', 'value', 'text', 'default', 'module_override_select');
		$html .= '<span class="input-group-btn"><input class="btn btn-secondary" type="button" value="'.JText::_('TPL_GK_LANG_ADD_RULE').'" id="module_override_add_btn" /></span></div>';
		$html .= '<textarea class="form-control" name="'.$this->name.'" id="'.$this->id.'">' . htmlspecialchars($this->value, ENT_COMPAT, 'UTF-8') . '</textarea>';
		$html .= '<div id="module_override_rules"></div>';
		$html .= '</div>';

		return $html;
	}
}