<?php

class JFormFieldInsetWidthOverride extends JFormField
{
	public $type = 'InsetWidthOverride';

	protected function getInput() {
		$html = '';
		$html .= '<div id="inset_width_for_pages_form">';
		$html .= '<div class="input-group"><span class="input-group-addon">' . JText::_('TPL_GK_LANG_ADD_RULE_ITEMID_OPTION') . '</span>';
		$html .= '<input class="form-control" type="text" id="inset_width_for_pages_input" /></div>';
		$html .= '<div class="input-group"><span class="input-group-addon">' . JText::_('TPL_GK_LANG_ADD_RULE_WIDTH') . '</span>';
		$html .= '<input class="form-control" type="text" value="" id="inset_width_for_pages_select" class="form-control" /><span class="input-group-addon">%</span>';
		$html .= '<span class="input-group-btn"><input class="btn btn-secondary" class="btn btn-secondary" value="'.JText::_('TPL_GK_LANG_ADD_RULE').'" id="inset_width_for_pages_add_btn" /></span></div>';
		$html .= '<textarea class="form-control" name="'.$this->name.'" id="'.$this->id.'">' . htmlspecialchars($this->value, ENT_COMPAT, 'UTF-8') . '</textarea>';
		$html .= '<div id="inset_width_for_pages_rules"></div>';
		$html .= '</div>';

		return $html;
	}
}
