<?php

class JFormFieldLayoutOverride extends JFormField
{
	public $type = 'LayoutOverride';

	protected function getInput() {
		$options = (array) $this->getOptions();
		$html = '';
		$html .= '<div id="layout_override_form">';
		$html .= '<div class="input-group"><span class="input-group-addon">' . JText::_('TPL_GK_LANG_ADD_RULE_ITEMID_OPTION') . '</span>';
		$html .= '<input class="form-control" type="text" id="layout_override_input" /></div>';
		$html .= '<div class="input-group"><span class="input-group-addon">' . JText::_('TPL_GK_LANG_ADD_RULE_LAYOUT') . '</span>';
		$html .= JHtml::_('select.genericlist', $options, 'name', 'class="form-control custom-select"', 'value', 'text', 'default', 'layout_override_select');
		$html .= '<span class="input-group-btn"><input class="btn btn-secondary" type="button" value="'.JText::_('TPL_GK_LANG_ADD_RULE').'" id="layout_override_add_btn" /></sapn></div>';
		$html .= '<textarea class="form-control" name="'.$this->name.'" id="'.$this->id.'">' . htmlspecialchars($this->value, ENT_COMPAT, 'UTF-8') . '</textarea>';
		$html .= '<div id="layout_override_rules"></div>';
		$html .= '</div>';

		return $html;
	}

	protected function getOptions() {
		$options = array();
		$path = (string) $this->element['directory'];
		if (!is_dir($path)) $path = JPATH_ROOT.'/'.$path;
		$files = JFolder::files($path, '.php');

		if (is_array($files)) {
			foreach($files as $file) {
				$file = JFile::stripExt($file);
				$options[] = JHtml::_('select.option', $file, $file);
			}
		}

		return array_merge($options);
	}
}
