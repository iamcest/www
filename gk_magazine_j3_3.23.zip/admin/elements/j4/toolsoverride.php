<?php

class JFormFieldToolsOverride extends JFormField
{
	public $type = 'ToolsOverride';

	protected function getInput() {
		$options = array(JHtml::_('select.option', JText::_('TPL_GK_LANG_ENABLED'), 'enabled'), JHtml::_('select.option', JText::_('TPL_GK_LANG_DISABLED'), 'disabled'));
		$html = '';
		$html .= '<div id="tools_for_pages_form">';
		$html .= '<div class="input-group"><span class="input-group-addon">' . JText::_('TPL_GK_LANG_ADD_RULE_ITEMID_OPTION') . '</span>';
		$html .= '<input class="form-control" type="text" id="tools_for_pages_input" />';
		$html .= '<span class="input-group-btn"><input class="btn btn-secondary" type="button" value="'.JText::_('TPL_GK_LANG_ADD_RULE').'" id="tools_for_pages_add_btn" /></span></div>';
		$html .= '<textarea class="form-control" name="'.$this->name.'" id="'.$this->id.'">' . htmlspecialchars($this->value, ENT_COMPAT, 'UTF-8') . '</textarea>';
		$html .= '<div id="tools_for_pages_rules"></div>';
		$html .= '</div>';

		return $html;
	}
}
