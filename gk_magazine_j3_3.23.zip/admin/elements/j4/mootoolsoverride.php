<?php

class JFormFieldMooToolsOverride extends JFormField
{
	public $type = 'MooToolsOverride';

	protected function getInput() {
		$options = array(JHtml::_('select.option', JText::_('TPL_GK_LANG_ENABLED'), 'enabled'), JHtml::_('select.option', JText::_('TPL_GK_LANG_DISABLED'), 'disabled'));
		$html = '';
		$html .= '<div id="mootools_for_pages_form">';
		$html .= '<div class="input-group"><span class="input-group-addon">' . JText::_('TPL_GK_LANG_ADD_RULE_ITEMID_OPTION') . '</span>';
		$html .= '<input class="form-control" type="text" id="mootools_for_pages_input" /></div>';
		$html .= '<div class="input-group"><span class="input-group-addon">' . JText::_('TPL_GK_LANG_ADD_RULE_STATE') . '</span>';
		$html .= JHtml::_('select.genericlist', $options, 'name', 'class="form-control custom-select"', 'value', 'text', 'default', 'mootools_for_pages_select');
		$html .= '<span class="input-group-btn"><input class="btn btn-secondary" type="button" value="'.JText::_('TPL_GK_LANG_ADD_RULE').'" id="mootools_for_pages_add_btn" /></span></div>';
		$html .= '<textarea class="form-control" name="'.$this->name.'" id="'.$this->id.'">' . htmlspecialchars($this->value, ENT_COMPAT, 'UTF-8') . '</textarea>';
		$html .= '<div id="mootools_for_pages_rules"></div>';
		$html .= '</div>';

		return $html;
	}
}
