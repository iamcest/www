<?php

class JFormFieldGoogleAnalytics extends JFormField
{
	public $type = 'GoogleAnalytics';

	protected function getInput() {
		$html = '<div id="google_analytics_form">';
		$html .= '<div class="input-group"><div class="input-group-addon">' . JText::_('TPL_GK_LANG_ADD_RULE_GA_CODE') . '</div>';
		$html .= '<input class="form-control" type="text" placeholder="UA-XXXXXX" id="google_analytics_input" />';
		$html .= '<span class="input-group-btn"><input class="btn btn-secondary" type="button" value="'.JText::_('TPL_GK_LANG_ADD_RULE').'" id="google_analytics_add_btn" /></span></div>';
		$html .= '<textarea class="form-control" name="'.$this->name.'" id="'.$this->id.'">' . htmlspecialchars($this->value, ENT_COMPAT, 'UTF-8') . '</textarea>';
		$html .= '<div id="google_analytics_rules"></div>';
		$html .= '</div>';
		
		return $html;
	}
}
