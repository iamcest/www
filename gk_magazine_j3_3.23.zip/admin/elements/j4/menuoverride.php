<?php

class JFormFieldMenuOverride extends JFormField
{
	public $type = 'MenuOverride';

	protected function getInput() {
		$options = array(JHtml::_('select.option', 'gk_menu', 'GK Extra Menu'), JHtml::_('select.option', 'gk_dropline', 'GK Dropline Menu'), JHtml::_('select.option', 'gk_split', 'GK Split Menu'));

		$html = '';
		$html .= '<div id="menu_override_form">';
		$html .= '<div class="input-group"><span class="input-group-addon">' . JText::_('TPL_GK_LANG_ADD_RULE_ITEMID_OPTION') . '</span>';
		$html .= '<input class="form-control" type="text" id="menu_override_input" /></div>';
		$html .= '<div class="input-group"><span class="input-group-addon">' . JText::_('TPL_GK_LANG_ADD_RULE_MENU_TYPE') . '</span>';
		$html .= JHtml::_('select.genericlist', $options, 'name', 'class="form-control custom-select"', 'value', 'text', 'default', 'menu_override_select');
		$html .= '<span class="input-group-btn"><input class="btn btn-secondary" value="'.JText::_('TPL_GK_LANG_ADD_RULE').'" id="menu_override_add_btn" /></span></div>';
		$html .= '<textarea class="form-control" name="'.$this->name.'" id="'.$this->id.'">' . htmlspecialchars($this->value, ENT_COMPAT, 'UTF-8') . '</textarea>';
		$html .= '<div id="menu_override_rules"></div>';
		$html .= '</div>';

		return $html;
	}
}
