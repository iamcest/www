<?php

class JFormFieldSuffixOverride extends JFormField
{
	public $type = 'SuffixOverride';

	protected function getInput() {
		$html = '';
		$html .= '<div id="suffix_override_form">';
		$html .= '<div class="input-group"><span class="input-group-addon">' . JText::_('TPL_GK_LANG_ADD_RULE_ITEMID_OPTION') . '</span>';
		$html .= '<input class="form-control" type="text" id="suffix_override_input" /></div>';
		$html .= '<div class="input-group"><span class="input-group-addon">' . JText::_('TPL_GK_LANG_ADD_RULE_SUFFIX') . '</span>';
		$html .= '<input class="form-control" type="text" id="suffix_override_select" />';
		$html .= '<span class="input-group-btn"><input class="btn btn-secondary" type="button" value="'.JText::_('TPL_GK_LANG_ADD_RULE').'" id="suffix_override_add_btn" /></span></div>';
		$html .= '<textarea class="form-control" name="'.$this->name.'" id="'.$this->id.'">' . htmlspecialchars($this->value, ENT_COMPAT, 'UTF-8') . '</textarea>';
		$html .= '<div id="suffix_override_rules"></div>';
		$html .= '</div>';

		return $html;
	}
}
